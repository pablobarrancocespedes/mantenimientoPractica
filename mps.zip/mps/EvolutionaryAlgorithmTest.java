/*Autores:
 * Pablo Barranco Céspedes
 * Raquel Ferreira Macayo
 */
package org.mps;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mps.crossover.OnePointCrossover;
import org.mps.mutation.SwapMutation;
import org.mps.selection.TournamentSelection;

public class EvolutionaryAlgorithmTest {
    @Test
    @DisplayName("Si tournament selection es null el constructor lanza una excepcion")
    public void evolutionaryAlgorithmTest_tournamentSelectionNull_throwsException() throws EvolutionaryAlgorithmException{
        SwapMutation mo = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        assertThrows(EvolutionaryAlgorithmException.class, () -> new EvolutionaryAlgorithm(null,mo,opc));
    }

    @Test
    @DisplayName("Si mutation operator es null el constructor lanza una excepcion")
    public void evolutionaryAlgorithmTest_mutationOperatorNull_throwsException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        OnePointCrossover opc = new OnePointCrossover();
        assertThrows(EvolutionaryAlgorithmException.class, () -> new EvolutionaryAlgorithm(ts,null,opc));
    }

    @Test
    @DisplayName("Si selection operator es null el constructor lanza una excepcion")
    public void evolutionaryAlgorithmTest_selectionOperatorNull_throwsException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        SwapMutation mo = new SwapMutation();
        assertThrows(EvolutionaryAlgorithmException.class, () -> new EvolutionaryAlgorithm(ts,mo,null));
    }

    @Test
    @DisplayName("setMutationOperator guarda el nuevo mutationOperator")
    public void setMutationOperatorTest_returnTrue() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(3);
        SwapMutation sm1 = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, sm1, opc);
        SwapMutation sm2 = new SwapMutation();
        ea.setMutationOperator(sm2);
        assertEquals(sm2, ea.getMutationOperator());
    }

    @Test
    @DisplayName("setSelectionOperator guarda el nuevo selectionOperator")
    public void setSelectorOperatorTest_returnTrue() throws EvolutionaryAlgorithmException{
        TournamentSelection ts1 = new TournamentSelection(3);
        SwapMutation sm = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts1, sm, opc);
        TournamentSelection ts2 = new TournamentSelection(3);
        ea.setSelectionOperator(ts2);
        assertEquals(ts2, ea.getSelectionOperator());
    }

    @Test
    @DisplayName("setCrossoverOperator guarda el nuevo crossoverOperator")
    public void setCrossoverOperatorTest_returnTrue() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(3);
        SwapMutation sm = new SwapMutation();
        OnePointCrossover opc1 = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, sm, opc1);
        OnePointCrossover opc2 = new OnePointCrossover();
        ea.setCrossoverOperator(opc2);
        assertEquals(opc2, ea.getCrossoverOperator());
    }

    @Test
    @DisplayName("Optimize funciona correctamente y devuelve una matriz de la misma longitud que la de entrada")
    public void optimizeTest_returnTrue() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(3);
        SwapMutation sm = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, sm, opc);
        int[][] population = { {4, 5, 6}, {1,2,3}};
        int [][] finalPopulation = ea.optimize(population);
        assertEquals(population.length, finalPopulation.length);
        assertNotNull(finalPopulation);
    }

    @Test
    @DisplayName("optimize lanza excepcion si population es null")
    public void optimizeTest_populationNull_throwException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        SwapMutation sm = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, sm, opc);
        assertThrows(EvolutionaryAlgorithmException.class, () -> ea.optimize(null));
    }

    @Test
    @DisplayName("optimize lanza excepcion si population.length == 0")
    public void optimizeTest_populationLengthIgualACero_throwsException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        SwapMutation mo = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, mo, opc);

        int[][] population = {};
        
        assertThrows(EvolutionaryAlgorithmException.class, () -> ea.optimize(population));
    }

    @Test
    @DisplayName("optimize lanza excepcion si population[0] == null")
    public void optimizeTest_populationFilaPrimeraNula_throwsException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        SwapMutation mo = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, mo, opc);

        int[][] population = {null, {0,1}};
        
        assertThrows(EvolutionaryAlgorithmException.class, () -> ea.optimize(population));
    } 

    @Test
    @DisplayName("optimize lanza excepcion si population[0].length == 0")
    public void optimizeTest_populationFilaPrimeraLengthIgualACero_throwsException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        SwapMutation mo = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, mo, opc);

        int[][] population = {{},
                            {0,1}};
        
        assertThrows(EvolutionaryAlgorithmException.class, () -> ea.optimize(population));
    }

    @Test
    @DisplayName("optimize lanza excepcion si population.length%2 != 0")
    public void optimizeTest_populationLengthImpar_throwsException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        SwapMutation mo = new SwapMutation();
        OnePointCrossover opc = new OnePointCrossover();
        EvolutionaryAlgorithm ea = new EvolutionaryAlgorithm(ts, mo, opc);

        int[][] population = {{0,1,2},
                            {0,1,2},
                            {0,1,2}};
        
        assertThrows(EvolutionaryAlgorithmException.class, () -> ea.optimize(population));
    }
    
    

    private void probarExcepcion() throws EvolutionaryAlgorithmException{
        throw new EvolutionaryAlgorithmException();
    }

    @Test
    @DisplayName("test de la excepcion sin mensaje")
    public void evolutionaryAlgorithmTest_noMessage_throwException(){
        assertThrows(EvolutionaryAlgorithmException.class,() -> this.probarExcepcion());
    }

}
