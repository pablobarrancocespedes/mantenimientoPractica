/*Autores:
 * Pablo Barranco Céspedes
 * Raquel Ferreira Macayo
 */
package org.mps.selection;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mps.EvolutionaryAlgorithmException;

public class TournamentSelectionTest {
    
    @Test
    @DisplayName("TournamentSelection lanza una excepcion al ser el tournamentSize menor que 0")
    public void tournamentSelectionTest_throwsEvolutionaryAlgorithmException(){
        assertThrows(EvolutionaryAlgorithmException.class,()-> new TournamentSelection(0));
    }

    @Test
    @DisplayName("TournamentSelection lanza una excepcion al ser population nulo")
    public void selectTest_populationNull_throwsEvolutionaryAlgorithmException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        assertThrows(EvolutionaryAlgorithmException.class,()-> ts.select(null));
    }

    @Test
    @DisplayName("TournamentSelection lanza una excepcion al ser la longitud de population 0")
    public void selectTest_populationLength0_throwsEvolutionaryAlgorithmException() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(1);
        int [] population = {};
        assertThrows(EvolutionaryAlgorithmException.class,()-> ts.select(population));
    }

    @Test
    @DisplayName("TournamentSelection lanza una excepcion al ser la longitud de population 0")
    public void selectTest_return() throws EvolutionaryAlgorithmException{
        TournamentSelection ts = new TournamentSelection(3);
        int [] population = {1, 2, 3};
        int [] selected =  ts.select(population);
        assertEquals(population.length,selected.length);
        assertNotNull(selected);
        
    }



}
