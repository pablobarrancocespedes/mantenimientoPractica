/*Autores:
 * Pablo Barranco Céspedes
 * Raquel Ferreira Macayo
 */
package org.mps.mutation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mps.EvolutionaryAlgorithmException;

public class SwapMutationTest {
    
    @Test
    @DisplayName("Mutate test lanza una excepcion al ser individual nulo")
    public void mutateTest_individualNull_throwEvolutionaryAlgorithmException(){
        SwapMutation sm = new SwapMutation();
        assertThrows(EvolutionaryAlgorithmException.class,()->  sm.mutate(null));
    }

    @Test
    @DisplayName("Mutate test lanza una excepcion al ser la longitud de individual 0")
    public void mutateTest_individualLength0_throwEvolutionaryAlgorithmException(){
        SwapMutation sm = new SwapMutation();
        int [] individual = {};
        assertThrows(EvolutionaryAlgorithmException.class,()->  sm.mutate(individual));
    }

    @Test
    @DisplayName("Mutate test comprueba que se realiza la funcion de forma correcta")
    public void mutateTest_return() throws EvolutionaryAlgorithmException{
        SwapMutation sm = new SwapMutation();
        int [] individual = {1, 2};
        int [] mutatedIndividual = sm.mutate(individual);
        assertEquals(individual.length, mutatedIndividual.length);
        assertNotNull(mutatedIndividual);
    }

}
