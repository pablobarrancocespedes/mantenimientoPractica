/*Autores:
 * Pablo Barranco Cespedes
 * Raquel Ferreira Macayo
 */
package org.mps.boundedqueue;
import static org.assertj.core.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ArrayBoundedQueueTest {
    
    @Test
    @DisplayName("el constructor lanza una excepcion si capacity es negativo")
    public void arrayBoundedQueueTest_capacityMenorQueCero_throwsException(){
        assertThatExceptionOfType(IllegalArgumentException.class).isThrownBy(() -> new ArrayBoundedQueue<>(0));
    }

    @Test
    @DisplayName("put lanza excepcion al estar la cola llena")
    public void putTest_ColaLlena_throwsFullBoundedQueueException(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(1);
        cola.put(1);
        assertThatExceptionOfType(FullBoundedQueueException.class).isThrownBy(()->cola.put(2));
    }

    @Test
    @DisplayName("put lanza excepcion al ser el value nulo")
    public void putTest_ValueNull_throwsFullBoundedQueueException(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(1);
        assertThatExceptionOfType(IllegalArgumentException.class).isThrownBy(()->cola.put(null));
    }

    @Test
    @DisplayName("get lanza una excepcion si la cola esta vacia")
    public void getTest_colaVacia_throwsException(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(1);
        assertThatExceptionOfType(EmptyBoundedQueueException.class).isThrownBy(() -> cola.get());
    }

    @Test
    @DisplayName("size devuelve el numero de elementos no nulos de la cola")
    public void sizeTest_returnTrue(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(3);
        cola.put(1);
        cola.put(2);
        assertThat(cola.size()).isEqualTo(2);
    }

    @Test
    @DisplayName("getFirst devuelve el indice del primer elemento no nulo")
    public void getFirstTest_returnTrue(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(3);
        cola.put(1);
        assertThat(cola.getFirst()).isEqualTo(0);
    }

    @Test
    @DisplayName("getLast devuelve el indice del ultimo elemento no nulo")
    public void getLastTest_returnTrue(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(3);
        cola.put(1);
        assertThat(cola.getLast()).isEqualTo(1);
    }

    @Test
    @DisplayName("get extrae de la cola el primer elemento")
    public void getTest_colaNoVacia_returnTrue(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(1);
        ArrayBoundedQueue<Integer> cola2 = new ArrayBoundedQueue<>(1);
        cola.put(1);
        cola.get();
        assertThat(cola.getFirst() == cola2.getFirst()).isTrue();
        assertThat(cola.size() == 0).isTrue();
        assertThat(cola.getFirst() == 0).isTrue();
    }

    @Test
    @DisplayName("hasNext devuelve true si el iterador tiene un siguiente elemento")
    public void iteratorTest_hasNext_returnTrue(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(2);
        cola.put(1);
        cola.put(2);
        assertThat(cola.iterator().hasNext()).isTrue();
    }

    @Test
    @DisplayName("hasNext devuelve false si el iterador no tiene un siguiente elemento")
    public void iteratorTest_NoHasNext_returnFalse(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(1);
        assertThat(cola.iterator().hasNext()).isFalse();
    }

    @Test
    @DisplayName("next lanza excepcion si el iterador no tiene un siguiente elemento")
    public void iteratorTest_Next_throwsNoSuchElementException(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(1);
        assertThatExceptionOfType(NoSuchElementException.class).isThrownBy(()-> cola.iterator().next());
    }

    @Test
    @DisplayName("next devuelve el elemento siguiente del iterador")
    public void iteratorTest_Next_returnTrue(){
        ArrayBoundedQueue<Integer> cola = new ArrayBoundedQueue<>(2);
        cola.put(1);
        cola.put(2);
        assertThat(cola.iterator().next()).isEqualTo(1);
    }

}
