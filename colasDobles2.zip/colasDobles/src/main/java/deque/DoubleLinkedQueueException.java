package deque;

public class DoubleLinkedQueueException extends RuntimeException {
    public DoubleLinkedQueueException(String message) {
        super(message);
    }
}
