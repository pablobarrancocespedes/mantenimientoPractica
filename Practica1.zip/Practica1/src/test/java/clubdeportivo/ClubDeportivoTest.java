package clubdeportivo;
/*
 * Autores:
 * Pablo Barranco Cespedes
 * Raquel Ferreira Macayo
 */
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


class ClubDeportivoTest{

    @Test
    public void ClubDeportivoTest_grupoCeroONegativo_returnException(){
        assertThrows(ClubException.class, () -> new ClubDeportivo( "cd", 0));
    }
    
    @Test
    @DisplayName("plazas libres devuelve el numero de plazas libres para una actividad")
    public void plazasLibresTest_actividadExiste_returnTrue(){
        try {
            ClubDeportivo clubDeportivo = new ClubDeportivo("cd");
            Grupo grupo = new Grupo("codigo", "natacion", 3, 2, 1);
            clubDeportivo.anyadirActividad(grupo);
            assertEquals(1, clubDeportivo.plazasLibres("natacion"));
        } catch (ClubException e) {
            e.getMessage();
        }
    }

    @Test
    @DisplayName("plazas libres devuelve el numero de plazas libres para una actividad")
    public void plazasLibresTest_actividadNoExiste_returnTrue(){
        try {
            ClubDeportivo clubDeportivo = new ClubDeportivo("cd");
            Grupo grupo = new Grupo("codigo", "natacion", 3, 2, 1);
            clubDeportivo.anyadirActividad(grupo);
            assertEquals(0, clubDeportivo.plazasLibres("atletismos"));
        } catch (ClubException e) {
            e.getMessage();
        }
    }

    @Test
    @DisplayName("ingresos devuelve la cantidad de dinero que ingresa el club deportivo")
    public void ingresosTest_returnTrue(){
        try {
            ClubDeportivo clubDeportivo = new ClubDeportivo("cd");
            String[] datos1 = {"codigo", "actividad","3", "2", "1"};
            String[] datos2 = {"codigo", "actividad","3", "1", "1"};
            clubDeportivo.anyadirActividad(datos1);
            clubDeportivo.anyadirActividad(datos2);
            assertEquals(2, clubDeportivo.ingresos());
        } catch (ClubException e) {
            e.getMessage();
        }
    }

    @Test
    @DisplayName("Anyadir actividad lanza una excepcion al ser la longitud de datos menos que 5")
    public void anyadirActividadTest_LongitudDatosMenorQue5_returnTrue() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd");
        String[] datos = {"codigo", "actividad"};
        assertThrows(ClubException.class, ()-> clubdeportivo.anyadirActividad(datos));
        
    }

    @Test
    @DisplayName("Anyadir actividad lanza una excepcion al ser el formato de los datos incorrecto")
    public void anyadirActividadTest_DatosIncorrectos_returnTrue() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd");
        String[] datos = {"codigo", "actividad","2.3", "1", "2"};
        assertThrows(ClubException.class, ()-> clubdeportivo.anyadirActividad(datos));
        
    }

    @Test
    @DisplayName("Anyadir actividad lanza una excepcion al ser nulo el grupo")
    public void anyadirActividadTest_GrupoNulo_returnTrue() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd");
        Grupo grupo = null;
        assertThrows(ClubException.class, ()-> clubdeportivo.anyadirActividad(grupo));
        
    }

    @Test
    @DisplayName("Anyadir actividad lanza una excepcion al ser ngrupos mayor que la longitud de grupos")
    public void anyadirActividadTest_nGruposMayorQueLongitudGrupos_returnTrue() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd",1);
        Grupo grupo = new Grupo("codigo", "natacion", 2, 1, 2);
        clubdeportivo.anyadirActividad(grupo);
        Grupo grupo1 = new Grupo("codigo2", "atletismo", 2, 1, 2);
        assertThrows(ClubException.class, ()-> clubdeportivo.anyadirActividad(grupo1));
        
    }

    @Test
    @DisplayName("ToString devuelve el club deportivo pasado a string")
    public void toStringTest_returnTrue() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd");
        Grupo grupo = new Grupo("codigo", "natacion", 2, 1, 2);
        clubdeportivo.anyadirActividad(grupo);
        Grupo grupo1 = new Grupo("codigo", "atletismo", 2, 1, 2);
        clubdeportivo.anyadirActividad(grupo1);
        grupo.actualizarPlazas(3);
        clubdeportivo.anyadirActividad(grupo);
        assertEquals("cd --> [ " + grupo.toString() + ", " + grupo1.toString() + " ]", clubdeportivo.toString());
    }


    @Test
    @DisplayName("Matricular debe lanzar una excepcion al ser plazas mayor que el npersonas")
    public void matricularTest_plazasMenorQueNPersonas_returnThrowException() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd");
        Grupo grupo = new Grupo("codigo", "natacion", 2, 1, 2);
        clubdeportivo.anyadirActividad(grupo);
        assertThrows(ClubException.class, ()-> clubdeportivo.matricular("natacion", 100));
    }


    
    @Test
    @DisplayName("Matricular debe matricular a npersonas en la actividad")
    public void matricularTest_plazasMayorQueNPersonas_returnTrue() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd");
        Grupo grupo1 = new Grupo("codigo", "natacion", 2, 1, 2);
        Grupo grupo2 = new Grupo("codigo", "atletismo", 2, 1, 2);
        Grupo grupo3 = new Grupo("codigo1", "atletismo", 2, 0, 2);
        clubdeportivo.anyadirActividad(grupo1);
        clubdeportivo.anyadirActividad(grupo2);
        clubdeportivo.anyadirActividad(grupo3);
        clubdeportivo.matricular("atletismo", 2);
        assertEquals(clubdeportivo.plazasLibres("atletismo"),1);
    }

    @Test
    @DisplayName("Si NPersonas es 0 no se matricula a nadie")
    public void matricularTest_NPersonasIgual0_returnTrue() throws ClubException{
        ClubDeportivo clubdeportivo = new ClubDeportivo("cd");
        Grupo grupo1 = new Grupo("codigo", "natacion", 2, 1, 2);
        Grupo grupo2 = new Grupo("codigo", "atletismo", 2, 1, 2);
        Grupo grupo3 = new Grupo("codigo1", "atletismo", 2, 0, 2);
        clubdeportivo.anyadirActividad(grupo1);
        clubdeportivo.anyadirActividad(grupo2);
        clubdeportivo.anyadirActividad(grupo3);
        clubdeportivo.matricular("atletismo", 0);
        assertEquals(clubdeportivo.plazasLibres("atletismo"),3);
    }


}


