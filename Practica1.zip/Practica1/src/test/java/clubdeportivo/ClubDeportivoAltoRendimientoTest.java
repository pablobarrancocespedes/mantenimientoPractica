package clubdeportivo;
/*
 * Autores:
 * Pablo Barranco Cespedes
 * Raquel Ferreira Macayo
 */
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ClubDeportivoAltoRendimientoTest {
    @Test
    @DisplayName("El constructor lanza una excepcion si incremento es menor que 0")
    public void ClubDeportivoAltoRendimientoTest_incrementoMenorQueCero_throwException(){
        assertThrows(ClubException.class, () -> new ClubDeportivoAltoRendimiento("Vals", 1, -1));
    }

    @Test
    @DisplayName("El constructor lanza una excepcion si maximo es menor que 0")
    public void ClubDeportivoAltoRendimientoTest_maximoMenorQueCero_throwException(){
        assertThrows(ClubException.class, () -> new ClubDeportivoAltoRendimiento("Vals", -1, 1));
    }

    @Test
    @DisplayName("El constructor lanza una excepcion si incremento es menor que 0")
    public void ClubDeportivoAltoRendimientoTest_incrementoMenorQueCero2_throwException(){
        assertThrows(ClubException.class, () -> new ClubDeportivoAltoRendimiento("Vals", 3, 1, -1));
    }

    @Test
    @DisplayName("El constructor lanza una excepcion si maximo es menor que 0")
    public void ClubDeportivoAltoRendimientoTest_maximoMenorQueCero2_throwException(){
        assertThrows(ClubException.class, () -> new ClubDeportivoAltoRendimiento("Vals",3, -1, 1));
    }

    @Test
    @DisplayName("El constructor lanza una excepcion si ambos son menor que 0")
    public void ClubDeportivoAltoRendimientoTest_ambosMenorQueCero2_throwException(){
        assertThrows(ClubException.class, () -> new ClubDeportivoAltoRendimiento("Vals",3, -1, -1));
    }

    

    @Test
    @DisplayName("Ingresos devuelve los ingresos del club deportivo de alto rendimiento")
    public void ingresosTest_returnTrue(){
        try{
            ClubDeportivoAltoRendimiento clubDeportivo = new ClubDeportivoAltoRendimiento("cd",2,7);
            ClubDeportivoAltoRendimiento clubDeportivo2 = new ClubDeportivoAltoRendimiento("cd2",4,2,7);
            String[] datos = {"codigo", "natacion", "3", "2", "1"};
            String[] datos2 = {"codigo2", "natacion", "2", "2", "1"};
            clubDeportivo.anyadirActividad(datos);
            clubDeportivo.anyadirActividad(datos2);
            clubDeportivo2.anyadirActividad(datos);
            clubDeportivo2.anyadirActividad(datos2);
            double ingreso = (2*1+2*0.07)*2;
            assertEquals(clubDeportivo.ingresos(),ingreso);
            assertEquals(clubDeportivo2.ingresos(), ingreso);
            
        } catch (ClubException ex){
            ex.getMessage();
        }
        
    }

    @Test
    @DisplayName("La longitud de datos debe ser mayor o igual que 5 ")
    public void anyadirActividadTest_datosLengthMenorQue5_throwsException() throws ClubException{
        ClubDeportivoAltoRendimiento clubDeportivo = new ClubDeportivoAltoRendimiento("cd",2,7);
        String[] datos = {"codigo"};
        assertThrows(ClubException.class,()-> clubDeportivo.anyadirActividad(datos));
    }

    @Test
    @DisplayName("El formato de datos debe ser correcto")
    public void anyadirActividadTest_datosFormatoIncorrecto_throwsException() throws ClubException{
        ClubDeportivoAltoRendimiento clubDeportivo = new ClubDeportivoAltoRendimiento("cd",2,7);
        String[] datos = {"codigo", "actividad", "2.3", "2", "3"};
        assertThrows(ClubException.class,()-> clubDeportivo.anyadirActividad(datos));
    }

    


}