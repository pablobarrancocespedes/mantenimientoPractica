import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import clubdeportivo.ClubDeportivo;
import clubdeportivo.ClubException;
import clubdeportivo.Grupo;


class ClubDeportivoTest{

    @Test
    public void ClubDeportivoTest_grupoCeroONegativo_returnException(){
        assertThrows(ClubException.class, () -> new ClubDeportivo( "cd", 0));
    }
    
    @Test
    @DisplayName("plazas libres devuelve el numero de plazas libres para una actividad")
    public void plazasLibresTest_actividadExiste_returnTrue(){
        try {
            ClubDeportivo clubDeportivo = new ClubDeportivo("cd");
            Grupo grupo = new Grupo("codigo", "natacion", 3, 2, 1);
            clubDeportivo.anyadirActividad(grupo);
            assertEquals(1, clubDeportivo.plazasLibres("natacion"));
        } catch (ClubException e) {
            e.getMessage();
        }
    }

    @Test
    @DisplayName("plazas libres devuelve el numero de plazas libres para una actividad")
    public void plazasLibresTest_actividadNoExiste_returnTrue(){
        try {
            ClubDeportivo clubDeportivo = new ClubDeportivo("cd");
            Grupo grupo = new Grupo("codigo", "natacion", 3, 2, 1);
            clubDeportivo.anyadirActividad(grupo);
            assertEquals(0, clubDeportivo.plazasLibres("atletismos"));
        } catch (ClubException e) {
            e.getMessage();
        }
    }

    @Test
    @DisplayName("ingresos devuelve la cantidad de dinero que ingresa el club deportivo")
    public void ingresosTest_returnTrue(){
        try {
            ClubDeportivo clubDeportivo = new ClubDeportivo("cd");
            Grupo grupo1 = new Grupo("codigo", "natacion", 3, 4, 1);
            Grupo grupo2 = new Grupo("codigo", "natacion", 3, 5, 1);
            clubDeportivo.anyadirActividad(grupo1);
            clubDeportivo.anyadirActividad(grupo2);
            assertEquals(9, clubDeportivo.ingresos());
        } catch (ClubException e) {
            e.getMessage();
        }
    }



}